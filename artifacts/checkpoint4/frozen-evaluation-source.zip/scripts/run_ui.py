"""Local display launcher. No model call on launch; explicit sidebar contrast for Streamlit 1.66."""
import subprocess
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
raise SystemExit(subprocess.call([sys.executable,'-m','streamlit','run',str(ROOT/'src/dataops_copilot/ui.py'),
    '--theme.sidebar.secondaryBackgroundColor=#24475b'],cwd=ROOT))
